package org.Mercury;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootEurekaApplicationTests {

    @Test
    void contextLoads() {
    }

}
