package org.mercury.controller;

import com.netflix.hystrix.contrib.javanica.annotation.DefaultProperties;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.ribbon.proxy.annotation.Hystrix;
import org.mercury.client.UserClient;
import org.mercury.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.netflix.ribbon.RibbonLoadBalancerClient;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@Controller
@RequestMapping("consumer/user")
@DefaultProperties(defaultFallback = "fallBreaker") //设置熔断的全局设置
public class UserController {

    /*@Autowired
    private RestTemplate restTemplate;*/

    @Autowired
    private UserClient userClient;


    @GetMapping
    @ResponseBody
    @HystrixCommand  //声明熔断方法：fallbackMethod = "querySelectUserFallBreaker"
    public String querySelectUser(@RequestParam("id") Long id) {
        /*if (id == 1) {
            throw new RuntimeException();   //测试服务熔断
        }*/
//        return restTemplate.getForObject("http://service-provider/user/" + id, String.class);
        return userClient.querySelectUserById(id).toString();
    }

    public String fallBreaker() {
        return "服务器繁忙，请稍后再试。。。";
    }
}
