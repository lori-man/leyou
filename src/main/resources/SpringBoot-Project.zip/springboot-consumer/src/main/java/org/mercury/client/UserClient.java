package org.mercury.client;

import org.mercury.entity.User;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(value = "service-provider", fallback = UserClientFallBack.class)
public interface UserClient {
    @GetMapping("user/{id}")
    public User querySelectUserById(@RequestParam("id") Long id);
}
