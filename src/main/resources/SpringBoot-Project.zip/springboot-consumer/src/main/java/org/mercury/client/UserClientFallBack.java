package org.mercury.client;

import org.mercury.entity.User;

public class UserClientFallBack implements UserClient {
    @Override
    public User querySelectUserById(Long id) {
        User user = new User();
        user.setUserName("服务器正忙");
        return user;
    }
}
