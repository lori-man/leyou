package org.mercury.config;

import com.alibaba.druid.pool.DruidDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

@Configuration
@EnableConfigurationProperties(JdbcProperties.class)  //引入配置类
public class JdbcConfig {

    @Autowired
    private JdbcProperties jdbcProperties;   //第一种

    /*   public JdbcProperties jdbcProperties() {   //第二种
           return new JdbcProperties();
       }*/
    @Bean
    public DataSource dataSource(JdbcProperties jdbcProperties) {  //第三种，参数
        DruidDataSource druidDataSource = new DruidDataSource();
        druidDataSource.setDriverClassName(jdbcProperties.getDriverClassName());
        druidDataSource.setUrl(jdbcProperties.getUrl());
        druidDataSource.setUsername(jdbcProperties.getUsername());
        druidDataSource.setPassword(jdbcProperties.getUsername());
        return druidDataSource;
    }
}
