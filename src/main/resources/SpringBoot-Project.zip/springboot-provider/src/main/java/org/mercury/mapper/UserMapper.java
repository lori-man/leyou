package org.mercury.mapper;

import org.mercury.entity.User;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface UserMapper extends tk.mybatis.mapper.common.Mapper<User> {

}
