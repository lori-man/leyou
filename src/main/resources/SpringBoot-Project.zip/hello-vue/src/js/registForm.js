const registForm={
    template: `
    <div>
    账号:<input type="text"></br>
    密码:<input type="text"></br>
    确认密码:<input type="text"></br>
    <input type="button" value="注册">
</div>
    `
}